import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown } from "lucide-react";
import { DocumentUpload } from "@/components/DocumentUpload";
import { FlashcardViewer } from "@/components/FlashcardViewer";
import { PracticeMode } from "@/components/PracticeMode";
import { AITutor } from "@/components/AITutor";
import { ProgressDashboard } from "@/components/ProgressDashboard";
import { ExamBuilder } from "@/components/ExamBuilder";
import { SummaryGenerator } from "@/components/SummaryGenerator";
import { MemoryBoost } from "@/components/MemoryBoost";
import { PremiumUpgrade } from "@/components/PremiumUpgrade";
import { ThemeToggle } from "@/components/ThemeToggle";
import type { Document, UserSubscription, StudySession } from "@/types";

export const Route = createFileRoute("/")({
  component: App,
});

function App() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [subscription, setSubscription] = useState<UserSubscription>({
    isPremium: false,
    features: {
      unlimitedDocuments: false,
      unlimitedStudySets: false,
      unlimitedQuizzes: false,
      premiumTutor: false,
      priorityProcessing: false,
      pdfExport: false,
      adFree: false,
      flashcardExport: false,
    },
  });

  const handleDocumentUploaded = (doc: Document) => {
    setDocuments((prev) => [...prev, doc]);
    setSelectedDocument(doc);
  };

  const handleUpgradeToPremium = () => {
    setSubscription({
      isPremium: true,
      subscribedAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      features: {
        unlimitedDocuments: true,
        unlimitedStudySets: true,
        unlimitedQuizzes: true,
        premiumTutor: true,
        priorityProcessing: true,
        pdfExport: true,
        adFree: true,
        flashcardExport: true,
      },
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors">
      <div className="container mx-auto px-4 py-4 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1 text-center">
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent mb-2">
                UltraLearn AI
              </h1>
              <p className="text-gray-600 dark:text-gray-400 text-base sm:text-lg">Your Comprehensive AI Study Assistant</p>
              {subscription.isPremium && (
                <Badge className="mt-2 bg-gradient-to-r from-yellow-500 to-orange-500">
                  <Crown className="w-4 h-4 mr-1" />
                  Premium Member
                </Badge>
              )}
            </div>
            <div className="ml-2">
              <ThemeToggle />
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 mb-6 sm:mb-8 dark:bg-gray-800">
            <TabsTrigger value="upload" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Upload</TabsTrigger>
            <TabsTrigger value="flashcards" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Flashcards</TabsTrigger>
            <TabsTrigger value="practice" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Practice</TabsTrigger>
            <TabsTrigger value="tutor" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">AI Tutor</TabsTrigger>
            <TabsTrigger value="progress" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Progress</TabsTrigger>
            <TabsTrigger value="exam" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Exam</TabsTrigger>
            <TabsTrigger value="summary" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Summary</TabsTrigger>
            <TabsTrigger value="memory" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Memory</TabsTrigger>
            <TabsTrigger value="premium" className="text-xs sm:text-sm dark:text-gray-300 dark:data-[state=active]:bg-gray-700 dark:data-[state=active]:text-white">Premium</TabsTrigger>
          </TabsList>

          <TabsContent value="upload">
            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-white">Document Upload System</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Upload PDF, Word, images, or text documents to generate AI-powered study materials
                </CardDescription>
              </CardHeader>
              <CardContent>
                <DocumentUpload
                  onDocumentUploaded={handleDocumentUploaded}
                  isPremium={subscription.isPremium}
                  documentCount={documents.length}
                />
                {documents.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-3 dark:text-white">Your Documents</h3>
                    <div className="grid gap-3">
                      {documents.map((doc) => (
                        <Card
                          key={doc.id}
                          className={`cursor-pointer transition-all hover:shadow-md dark:bg-gray-700 dark:border-gray-600 ${
                            selectedDocument?.id === doc.id ? "ring-2 ring-blue-500 dark:ring-blue-400" : ""
                          }`}
                          onClick={() => setSelectedDocument(doc)}
                        >
                          <CardContent className="p-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="font-medium dark:text-white">{doc.name}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                  {new Date(doc.uploadedAt).toLocaleDateString()}
                                </p>
                              </div>
                              <Badge variant="outline" className="dark:border-gray-500 dark:text-gray-300">{doc.type}</Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="flashcards">
            <FlashcardViewer selectedDocument={selectedDocument} isPremium={subscription.isPremium} />
          </TabsContent>

          <TabsContent value="practice">
            <PracticeMode selectedDocument={selectedDocument} isPremium={subscription.isPremium} />
          </TabsContent>

          <TabsContent value="tutor">
            <AITutor selectedDocument={selectedDocument} isPremium={subscription.isPremium} />
          </TabsContent>

          <TabsContent value="progress">
            <ProgressDashboard studySessions={studySessions} documents={documents} />
          </TabsContent>

          <TabsContent value="exam">
            <ExamBuilder selectedDocument={selectedDocument} isPremium={subscription.isPremium} />
          </TabsContent>

          <TabsContent value="summary">
            <SummaryGenerator selectedDocument={selectedDocument} isPremium={subscription.isPremium} />
          </TabsContent>

          <TabsContent value="memory">
            <MemoryBoost isPremium={subscription.isPremium} documents={documents} />
          </TabsContent>

          <TabsContent value="premium">
            <PremiumUpgrade
              subscription={subscription}
              onUpgrade={handleUpgradeToPremium}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
