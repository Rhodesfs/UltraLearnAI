import { ErrorBoundary } from "@/components/ErrorBoundary";
import { FloatingBanner } from "@/components/FloatingBanner";
import { Outlet, createRootRoute } from "@tanstack/react-router";
import { TanStackRouterDevtools } from "@tanstack/react-router-devtools";
import { ThemeProvider } from "@/contexts/ThemeContext";

export const Route = createRootRoute({
	component: Root,
});

function Root() {
	return (
		<ThemeProvider>
			<div className="flex flex-col min-h-screen bg-white dark:bg-gray-950 transition-colors">
				<ErrorBoundary tagName="main" className="flex-1">
					<Outlet />
				</ErrorBoundary>
				<TanStackRouterDevtools position="bottom-right" />
				<FloatingBanner position="bottom-left" />
			</div>
		</ThemeProvider>
	);
}
