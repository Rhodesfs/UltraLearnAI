// Type definitions for UltraLearn AI

export interface Document {
  id: string;
  name: string;
  type: string;
  uploadedAt: Date;
  fileUrl: string;
  fileKey: string;
  processedContent?: string;
}

export interface Flashcard {
  id: string;
  documentId: string;
  question: string;
  answer: string;
  hint?: string;
  explanation?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  nextReviewDate?: Date;
  correctCount: number;
  incorrectCount: number;
}

export interface QuizQuestion {
  id: string;
  documentId: string;
  type: 'multiple-choice' | 'true-false' | 'fill-blank' | 'short-answer' | 'matching';
  question: string;
  correctAnswer: string;
  options?: string[];
  explanation?: string;
}

export interface Quiz {
  id: string;
  documentId: string;
  title: string;
  questions: QuizQuestion[];
  timeLimit?: number;
  createdAt: Date;
}

export interface QuizResult {
  id: string;
  quizId: string;
  score: number;
  totalQuestions: number;
  timeSpent: number;
  answers: Record<string, string>;
  completedAt: Date;
}

export interface StudySession {
  id: string;
  documentId: string;
  type: 'flashcards' | 'quiz' | 'tutor' | 'exam' | 'spaced-repetition';
  startTime: Date;
  endTime?: Date;
  itemsStudied: number;
  correctAnswers: number;
}

export interface ProgressStats {
  totalStudySessions: number;
  totalTimeStudied: number;
  averageAccuracy: number;
  strongTopics: string[];
  weakTopics: string[];
  streakDays: number;
  lastStudyDate: Date;
}

export interface StudyRoom {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  members: string[];
  sharedDocuments: string[];
  createdAt: Date;
}

export interface UserSubscription {
  isPremium: boolean;
  subscribedAt?: Date;
  expiresAt?: Date;
  features: {
    unlimitedDocuments: boolean;
    unlimitedStudySets: boolean;
    unlimitedQuizzes: boolean;
    premiumTutor: boolean;
    priorityProcessing: boolean;
    pdfExport: boolean;
    adFree: boolean;
    flashcardExport: boolean;
  };
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface SpacedRepetitionItem {
  flashcardId: string;
  nextReview: Date;
  interval: number;
  easeFactor: number;
  repetitions: number;
}
