import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Check, Crown, Zap, Star, Loader2, CreditCard, AlertCircle, Gift, CheckCircle } from "lucide-react";
import type { UserSubscription } from "@/types";

interface PremiumUpgradeProps {
  subscription: UserSubscription;
  onUpgrade: () => void;
}

// Valid free premium key (one-time use)
const VALID_KEY = "MadlineNicholsispretty";
const USED_KEYS_STORAGE_KEY = "ultralearn_used_keys";

export function PremiumUpgrade({ subscription, onUpgrade }: PremiumUpgradeProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [redemptionKey, setRedemptionKey] = useState("");
  const [redemptionError, setRedemptionError] = useState<string | null>(null);
  const [redemptionSuccess, setRedemptionSuccess] = useState(false);
  const [isRedeeming, setIsRedeeming] = useState(false);

  /**
   * Handle free key redemption with one-time use tracking
   */
  const handleRedeemKey = async () => {
    setRedemptionError(null);
    setRedemptionSuccess(false);

    if (!redemptionKey.trim()) {
      setRedemptionError("Please enter a redemption key");
      return;
    }

    setIsRedeeming(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const enteredKey = redemptionKey.trim();

    // Check if key has already been used
    const usedKeys = JSON.parse(localStorage.getItem(USED_KEYS_STORAGE_KEY) || "[]") as string[];
    if (usedKeys.includes(enteredKey)) {
      setRedemptionError("This key has already been redeemed.");
      setIsRedeeming(false);
      return;
    }

    // Check if key is valid
    if (enteredKey === VALID_KEY) {
      // Mark key as used
      usedKeys.push(enteredKey);
      localStorage.setItem(USED_KEYS_STORAGE_KEY, JSON.stringify(usedKeys));

      setRedemptionSuccess(true);
      setRedemptionError(null);

      // Wait a moment to show success message
      setTimeout(() => {
        onUpgrade();
      }, 1500);
    } else {
      setRedemptionError("Invalid redemption key. Please check and try again.");
    }

    setIsRedeeming(false);
  };

  /**
   * Handle Google Play Billing subscription purchase
   *
   * PRODUCTION SETUP REQUIRED:
   * 1. Set up Google Play Console (https://play.google.com/console)
   * 2. Create in-app subscription product with ID: "premium_monthly" for $1.99/month
   * 3. Implement native Android bridge to expose AndroidBilling to WebView
   * 4. Create backend endpoint /api/verify-purchase to validate purchase tokens
   * 5. Store subscription status in user database
   *
   * Reference: https://developer.android.com/google/play/billing
   */
  const handlePurchase = async () => {
    setIsProcessing(true);
    setPaymentError(null);

    try {
      // Check if Google Play Billing is available (injected by native Android wrapper)
      if (typeof window !== 'undefined' && 'AndroidBilling' in window) {
        const billing = (window as any).AndroidBilling;

        // Query available subscription products
        const products = await billing.queryProductDetails(['premium_monthly']);

        if (!products || products.length === 0) {
          throw new Error('Premium subscription not available');
        }

        // Launch Google Play purchase flow
        const purchaseResult = await billing.launchBillingFlow({
          productId: 'premium_monthly',
          type: 'subs', // subscription type
        });

        // Verify purchase on backend (CRITICAL for security)
        if (purchaseResult.responseCode === 0 && purchaseResult.purchaseToken) {
          // Send purchase token to backend for server-side verification
          const response = await fetch('/api/verify-purchase', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              purchaseToken: purchaseResult.purchaseToken,
              productId: 'premium_monthly',
            }),
          });

          if (response.ok) {
            // Purchase verified, activate premium features
            onUpgrade();
          } else {
            throw new Error('Failed to verify purchase');
          }
        } else {
          throw new Error('Purchase was cancelled or failed');
        }
      } else {
        // Development/testing fallback
        setPaymentError('Google Play Billing is only available in the Android app. Please download the app from Google Play Store to subscribe.');
      }
    } catch (error) {
      console.error('Purchase failed:', error);
      setPaymentError(error instanceof Error ? error.message : 'Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (subscription.isPremium) {
    return (
      <Card className="border-2 border-yellow-500 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 dark:border-yellow-600">
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            <Crown className="w-8 h-8 text-yellow-600 dark:text-yellow-400" />
            <CardTitle className="text-2xl dark:text-white">Premium Member</CardTitle>
          </div>
          <CardDescription className="dark:text-gray-400">You're currently enjoying all premium features!</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Status</p>
                <p className="text-xl font-bold text-green-600 dark:text-green-400">Active</p>
              </div>
              <Badge className="bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-400 dark:border-green-600">
                <Star className="w-4 h-4 mr-1" />
                Premium
              </Badge>
            </div>
            {subscription.subscribedAt && (
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600 dark:text-gray-400">Subscribed</p>
                  <p className="font-medium dark:text-gray-200">{new Date(subscription.subscribedAt).toLocaleDateString()}</p>
                </div>
                {subscription.expiresAt && (
                  <div>
                    <p className="text-gray-600 dark:text-gray-400">Renews</p>
                    <p className="font-medium dark:text-gray-200">{new Date(subscription.expiresAt).toLocaleDateString()}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <div>
            <h3 className="font-semibold mb-3 dark:text-white">Your Premium Features:</h3>
            <div className="grid gap-2">
              {[
                "Unlimited document uploads",
                "Unlimited AI-generated study sets",
                "Unlimited custom quizzes",
                "Premium AI Tutor with unlimited questions",
                "Priority processing speed",
                "Downloadable PDF study guides",
                "Ad-free experience",
                "Flashcard export functionality",
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                  <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-900 dark:text-blue-300">
              Thank you for being a Premium member! You're unlocking the full potential of UltraLearn AI.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Free Key Redemption Section */}
      <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 dark:border-green-600">
        <CardHeader>
          <div className="flex items-center gap-2 mb-2">
            <Gift className="w-6 h-6 text-green-600 dark:text-green-400" />
            <CardTitle className="text-xl dark:text-white">Have a Free Premium Key?</CardTitle>
          </div>
          <CardDescription className="dark:text-gray-400">
            Redeem your free premium access code here
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Enter your redemption key"
              value={redemptionKey}
              onChange={(e) => setRedemptionKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleRedeemKey()}
              disabled={isRedeeming || redemptionSuccess}
              className="flex-1 dark:bg-gray-800 dark:border-gray-600 dark:text-white"
            />
            <Button
              onClick={handleRedeemKey}
              disabled={isRedeeming || redemptionSuccess}
              className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800 whitespace-nowrap"
            >
              {isRedeeming ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Redeeming...
                </>
              ) : redemptionSuccess ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Redeemed!
                </>
              ) : (
                <>
                  <Gift className="w-4 h-4 mr-2" />
                  Redeem Key
                </>
              )}
            </Button>
          </div>

          {redemptionError && (
            <Alert variant="destructive" className="dark:bg-red-900/20 dark:border-red-800">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{redemptionError}</AlertDescription>
            </Alert>
          )}

          {redemptionSuccess && (
            <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800">
              <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
              <AlertDescription className="text-green-800 dark:text-green-300">
                Success! Activating your premium access...
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Purchase Premium Section */}
      <Card className="border-2 border-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 dark:border-purple-600">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full p-4">
              <Crown className="w-12 h-12 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl sm:text-3xl mb-2 dark:text-white">Upgrade to Premium</CardTitle>
          <CardDescription className="text-base sm:text-lg dark:text-gray-400">
            Unlock unlimited learning potential for just $1.99/month
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="inline-block">
              <p className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
                $1.99
              </p>
              <p className="text-gray-600 dark:text-gray-400">/month</p>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-base sm:text-lg flex items-center gap-2 dark:text-white">
              <Zap className="w-5 h-5 text-yellow-500 dark:text-yellow-400" />
              Premium Features:
            </h3>
            <div className="grid gap-3">
              {[
                {
                  title: "Unlimited Document Uploads",
                  description: "Upload as many study materials as you need",
                },
                {
                  title: "Unlimited AI Study Sets",
                  description: "Generate infinite flashcards, quizzes, and summaries",
                },
                {
                  title: "Unlimited Custom Quizzes",
                  description: "Create practice tests whenever you want",
                },
                {
                  title: "Premium AI Tutor Access",
                  description: "Unlimited questions and personalized explanations",
                },
                {
                  title: "Priority Processing",
                  description: "Get your study materials generated faster",
                },
                {
                  title: "Downloadable PDF Study Guides",
                  description: "Export and print your study materials",
                },
                {
                  title: "Ad-Free Experience",
                  description: "Focus on learning without distractions",
                },
                {
                  title: "Flashcard Export",
                  description: "Export your flashcards to other platforms",
                },
              ].map((feature, idx) => (
                <div key={idx} className="flex gap-3 p-3 bg-white dark:bg-gray-800 rounded-lg">
                  <Check className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{feature.title}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {paymentError && (
            <Alert variant="destructive" className="dark:bg-red-900/20 dark:border-red-800">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{paymentError}</AlertDescription>
            </Alert>
          )}

          <Button
            onClick={handlePurchase}
            size="lg"
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-base sm:text-lg py-6"
            disabled={isProcessing}
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Processing Payment...
              </>
            ) : (
              <>
                <CreditCard className="w-5 h-5 mr-2" />
                Subscribe via Google Play - $1.99/month
              </>
            )}
          </Button>

          <div className="text-center text-xs sm:text-sm text-gray-600 dark:text-gray-400">
            <p>Cancel anytime • Billed through Google Play • Instant activation</p>
            <p className="mt-1 text-xs">Secure payment processed by Google Play Billing</p>
          </div>
        </CardContent>
      </Card>

      {/* Free Tier Comparison */}
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="dark:text-white">Free vs Premium</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-700 dark:text-gray-300">Free Tier</h4>
              <ul className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                <li>• Up to 3 documents</li>
                <li>• Limited AI generations</li>
                <li>• 5 AI Tutor questions/day</li>
                <li>• 1 study room</li>
                <li>• Basic features</li>
              </ul>
            </div>
            <div className="space-y-2 bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-purple-700 dark:text-purple-400 flex items-center gap-2">
                <Crown className="w-4 h-4" />
                Premium
              </h4>
              <ul className="space-y-1 text-sm text-purple-900 dark:text-purple-300">
                <li>• Unlimited documents</li>
                <li>• Unlimited AI generations</li>
                <li>• Unlimited AI Tutor</li>
                <li>• Unlimited study rooms</li>
                <li>• All premium features</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
