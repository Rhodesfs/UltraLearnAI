import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Users, Plus, Share2, Lock, FileText } from "lucide-react";
import type { Document, StudyRoom } from "@/types";

interface StudyRoomsProps {
  documents: Document[];
  isPremium: boolean;
}

export function StudyRooms({ documents, isPremium }: StudyRoomsProps) {
  const [studyRooms, setStudyRooms] = useState<StudyRoom[]>([
    {
      id: "1",
      name: "Biology Study Group",
      description: "Preparing for final exams",
      createdBy: "user123",
      members: ["user123", "user456", "user789"],
      sharedDocuments: [],
      createdAt: new Date("2024-11-15"),
    },
  ]);
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomDescription, setNewRoomDescription] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<StudyRoom | null>(null);
  const [isViewingRoom, setIsViewingRoom] = useState(false);

  const FREE_ROOM_LIMIT = 1;
  const canCreateRoom = isPremium || studyRooms.length < FREE_ROOM_LIMIT;

  const handleCreateRoom = () => {
    if (!newRoomName.trim()) return;

    const newRoom: StudyRoom = {
      id: crypto.randomUUID(),
      name: newRoomName,
      description: newRoomDescription,
      createdBy: "currentUser",
      members: ["currentUser"],
      sharedDocuments: [],
      createdAt: new Date(),
    };

    setStudyRooms([...studyRooms, newRoom]);
    setNewRoomName("");
    setNewRoomDescription("");
    setIsDialogOpen(false);
  };

  const handleViewRoom = (room: StudyRoom) => {
    setSelectedRoom(room);
    setIsViewingRoom(true);
  };

  const handleShareDocument = (room: StudyRoom, documentId: string) => {
    setStudyRooms(rooms =>
      rooms.map(r =>
        r.id === room.id
          ? { ...r, sharedDocuments: [...r.sharedDocuments, documentId] }
          : r
      )
    );
  };

  const handleInviteMember = (roomId: string) => {
    const inviteCode = `${roomId.slice(0, 8)}`;
    navigator.clipboard.writeText(`Join study room with code: ${inviteCode}`);
    alert(`Invite link copied to clipboard! Share code: ${inviteCode}`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Study Rooms</CardTitle>
              <CardDescription>Collaborate with classmates and share study materials</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button disabled={!canCreateRoom}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Room
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Study Room</DialogTitle>
                  <DialogDescription>
                    Set up a collaborative space to share study materials with your classmates
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="room-name">Room Name</Label>
                    <Input
                      id="room-name"
                      value={newRoomName}
                      onChange={(e) => setNewRoomName(e.target.value)}
                      placeholder="e.g., Biology Study Group"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="room-description">Description</Label>
                    <Textarea
                      id="room-description"
                      value={newRoomDescription}
                      onChange={(e) => setNewRoomDescription(e.target.value)}
                      placeholder="What is this study room for?"
                      rows={3}
                    />
                  </div>
                  <Button onClick={handleCreateRoom} className="w-full">
                    Create Study Room
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {!canCreateRoom && (
            <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg flex items-center gap-2">
              <Lock className="h-4 w-4 text-orange-600" />
              <p className="text-sm text-orange-700">
                Free users can create up to {FREE_ROOM_LIMIT} study room. Upgrade to Premium for unlimited rooms!
              </p>
            </div>
          )}

          {studyRooms.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No study rooms yet. Create one to get started!</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {studyRooms.map((room) => (
                <Card key={room.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-1">{room.name}</h3>
                        <p className="text-gray-600 text-sm mb-3">{room.description}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {room.members.length} members
                          </span>
                          <span className="flex items-center gap-1">
                            <Share2 className="w-4 h-4" />
                            {room.sharedDocuments.length} documents
                          </span>
                        </div>
                      </div>
                      <Badge variant="outline">Active</Badge>
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      <p className="text-sm font-medium text-gray-700">Members:</p>
                      <div className="flex -space-x-2">
                        {room.members.slice(0, 5).map((member, idx) => (
                          <Avatar key={idx} className="h-8 w-8 border-2 border-white">
                            <AvatarFallback className="bg-blue-500 text-white text-xs">
                              {member.slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                        {room.members.length > 5 && (
                          <Avatar className="h-8 w-8 border-2 border-white">
                            <AvatarFallback className="bg-gray-300 text-gray-700 text-xs">
                              +{room.members.length - 5}
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="flex-1"
                        onClick={() => handleViewRoom(room)}
                      >
                        View Room
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="flex-1">
                            Share Documents
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Share Documents to {room.name}</DialogTitle>
                            <DialogDescription>
                              Select documents to share with this study room
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-3 py-4">
                            {documents.length === 0 ? (
                              <p className="text-sm text-gray-500 text-center py-4">
                                No documents to share. Upload documents first.
                              </p>
                            ) : (
                              documents.map((doc) => (
                                <div
                                  key={doc.id}
                                  className="flex items-center justify-between p-3 border rounded-lg"
                                >
                                  <div>
                                    <p className="font-medium">{doc.name}</p>
                                    <p className="text-xs text-gray-500">{doc.type}</p>
                                  </div>
                                  <Button
                                    size="sm"
                                    onClick={() => handleShareDocument(room, doc.id)}
                                    disabled={room.sharedDocuments.includes(doc.id)}
                                  >
                                    {room.sharedDocuments.includes(doc.id) ? "Shared" : "Share"}
                                  </Button>
                                </div>
                              ))
                            )}
                          </div>
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="outline"
                        onClick={() => handleInviteMember(room.id)}
                        title="Invite members"
                      >
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Room Dialog */}
      <Dialog open={isViewingRoom} onOpenChange={setIsViewingRoom}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedRoom?.name}</DialogTitle>
            <DialogDescription>{selectedRoom?.description}</DialogDescription>
          </DialogHeader>
          {selectedRoom && (
            <div className="space-y-6 py-4">
              <div>
                <h3 className="font-semibold mb-3">Room Members ({selectedRoom.members.length})</h3>
                <div className="grid grid-cols-2 gap-2">
                  {selectedRoom.members.map((member, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 border rounded-lg">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-blue-500 text-white text-xs">
                          {member.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{member}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Shared Documents ({selectedRoom.sharedDocuments.length})</h3>
                {selectedRoom.sharedDocuments.length === 0 ? (
                  <p className="text-sm text-gray-500 py-4 text-center">
                    No documents shared yet. Use the "Share Documents" button to add documents.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {selectedRoom.sharedDocuments.map((docId) => {
                      const doc = documents.find(d => d.id === docId);
                      return doc ? (
                        <div key={docId} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-gray-500" />
                            <div>
                              <p className="font-medium">{doc.name}</p>
                              <p className="text-xs text-gray-500">{doc.type}</p>
                            </div>
                          </div>
                          <Badge variant="outline">Shared</Badge>
                        </div>
                      ) : null;
                    })}
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button onClick={() => handleInviteMember(selectedRoom.id)} className="flex-1">
                  <Share2 className="w-4 h-4 mr-2" />
                  Invite Members
                </Button>
                <Button variant="outline" onClick={() => setIsViewingRoom(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
