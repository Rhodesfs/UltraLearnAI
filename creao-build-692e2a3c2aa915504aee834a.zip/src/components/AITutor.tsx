import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Send, Bot, User, Lock, Loader2 } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document } from "@/types";

interface AITutorProps {
  selectedDocument: Document | null;
  isPremium: boolean;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export function AITutor({ selectedDocument, isPremium }: AITutorProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const aiMutation = useAIChatMutation();

  const FREE_MESSAGE_LIMIT = 5;
  const messageCount = messages.filter(m => m.role === "user").length;
  const canSendMessage = isPremium || messageCount < FREE_MESSAGE_LIMIT;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || !canSendMessage) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const chatHistory = messages.map(m => ({
        role: m.role,
        content: m.content,
      }));

      const result = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: `You are an expert AI tutor helping students learn. Be encouraging, break down complex topics into simple explanations, provide examples, and ask guiding questions. ${selectedDocument ? `The student is studying: ${selectedDocument.name}` : ""}`,
          },
          ...chatHistory,
          {
            role: "user",
            content: input,
          },
        ],
      });

      const assistantMessage: Message = {
        role: "assistant",
        content: result.content,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("AI Tutor error:", error);
      const errorMessage: Message = {
        role: "assistant",
        content: "I apologize, but I encountered an error. Please try again.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="h-[700px] flex flex-col">
      <CardHeader>
        <CardTitle>AI Tutor Mode</CardTitle>
        <CardDescription>
          {selectedDocument
            ? `Ask questions about ${selectedDocument.name}`
            : "Upload a document to get started with personalized tutoring"}
        </CardDescription>
        {!isPremium && (
          <Alert>
            <Lock className="h-4 w-4" />
            <AlertDescription>
              Free tier: {FREE_MESSAGE_LIMIT - messageCount} questions remaining. Upgrade for unlimited access!
            </AlertDescription>
          </Alert>
        )}
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4 min-h-0">
        <ScrollArea className="flex-1 pr-4" ref={scrollRef}>
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
              <Bot className="w-16 h-16 text-blue-500 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Welcome to AI Tutor!</h3>
              <p className="text-gray-600 mb-4">
                Ask me anything about your study material. I can:
              </p>
              <ul className="text-sm text-gray-600 space-y-2 text-left">
                <li>• Explain complex concepts in simple terms</li>
                <li>• Provide practice problems and examples</li>
                <li>• Answer questions about your documents</li>
                <li>• Help you prepare for exams</li>
              </ul>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-blue-500 text-white">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={`max-w-[80%] rounded-lg p-4 ${
                      message.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-gray-100 text-gray-900"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>
                    <p className="text-xs mt-2 opacity-70">
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                  {message.role === "user" && (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-purple-500 text-white">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-blue-500 text-white">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          )}
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={canSendMessage ? "Ask me anything..." : "Upgrade to Premium for more questions"}
            disabled={isLoading || !canSendMessage}
            className="flex-1"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!input.trim() || isLoading || !canSendMessage}
            size="icon"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
