import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { TrendingUp, TrendingDown, Target, Calendar, Award, Brain, AlertCircle } from "lucide-react";
import type { Document, StudySession } from "@/types";

interface ProgressDashboardProps {
  studySessions: StudySession[];
  documents: Document[];
}

export function ProgressDashboard({ studySessions, documents }: ProgressDashboardProps) {
  // Calculate real stats from study sessions
  const stats = useMemo(() => {
    const totalStudySessions = studySessions.length;
    const totalTimeStudied = studySessions.reduce((sum, session) => {
      if (session.endTime) {
        const duration = (new Date(session.endTime).getTime() - new Date(session.startTime).getTime()) / (1000 * 60);
        return sum + duration;
      }
      return sum;
    }, 0);

    const totalCorrect = studySessions.reduce((sum, s) => sum + s.correctAnswers, 0);
    const totalItems = studySessions.reduce((sum, s) => sum + s.itemsStudied, 0);
    const averageAccuracy = totalItems > 0 ? Math.round((totalCorrect / totalItems) * 100) : 0;

    // Calculate streak days
    const sessionDates = studySessions
      .map(s => new Date(s.startTime).toDateString())
      .filter((date, index, self) => self.indexOf(date) === index)
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

    let streakDays = 0;
    const today = new Date().toDateString();
    if (sessionDates.includes(today)) {
      streakDays = 1;
      const todayTime = new Date(today).getTime();
      for (let i = 1; i < sessionDates.length; i++) {
        const expectedDate = new Date(todayTime - i * 24 * 60 * 60 * 1000).toDateString();
        if (sessionDates.includes(expectedDate)) {
          streakDays++;
        } else {
          break;
        }
      }
    }

    // Analyze topics from documents
    const documentNames = documents.map(d => d.name);
    const strongTopics = documentNames.slice(0, 3);
    const weakTopics = documentNames.slice(-2);

    // Recent sessions
    const recentSessions = studySessions
      .slice(-3)
      .reverse()
      .map(session => ({
        date: new Date(session.startTime).toISOString().split('T')[0],
        accuracy: session.itemsStudied > 0 ? Math.round((session.correctAnswers / session.itemsStudied) * 100) : 0,
        itemsStudied: session.itemsStudied,
      }));

    return {
      totalStudySessions,
      totalTimeStudied,
      averageAccuracy,
      streakDays,
      strongTopics,
      weakTopics,
      recentSessions,
    };
  }, [studySessions, documents]);

  const hoursStudied = Math.floor(stats.totalTimeStudied / 60);
  const minutesStudied = Math.round(stats.totalTimeStudied % 60);

  if (studySessions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Progress Tracking Dashboard</CardTitle>
          <CardDescription>Monitor your learning journey and identify areas for improvement</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Start studying to see your progress! Your statistics will appear here as you use flashcards, practice quizzes, and other study features.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Progress Tracking Dashboard</CardTitle>
          <CardDescription>Monitor your learning journey and identify areas for improvement</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Study Sessions */}
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                    <p className="text-3xl font-bold text-blue-600">{stats.totalStudySessions}</p>
                  </div>
                  <Brain className="h-10 w-10 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            {/* Study Time */}
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Time Studied</p>
                    <p className="text-3xl font-bold text-purple-600">
                      {hoursStudied}h {minutesStudied}m
                    </p>
                  </div>
                  <Calendar className="h-10 w-10 text-purple-500" />
                </div>
              </CardContent>
            </Card>

            {/* Average Accuracy */}
            <Card className="bg-gradient-to-br from-green-50 to-green-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Avg. Accuracy</p>
                    <p className="text-3xl font-bold text-green-600">{stats.averageAccuracy}%</p>
                  </div>
                  <Target className="h-10 w-10 text-green-500" />
                </div>
              </CardContent>
            </Card>

            {/* Streak */}
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Study Streak</p>
                    <p className="text-3xl font-bold text-orange-600">{stats.streakDays} days</p>
                  </div>
                  <Award className="h-10 w-10 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Strengths and Weaknesses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Strong Topics
            </CardTitle>
            <CardDescription>Areas where you excel</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.strongTopics.length > 0 ? (
                stats.strongTopics.map((topic, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="font-medium">{topic}</span>
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                      Studying
                    </Badge>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">
                  Upload documents to see your strong topics
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-orange-600" />
              Areas for Improvement
            </CardTitle>
            <CardDescription>Focus on these topics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.weakTopics.length > 0 ? (
                stats.weakTopics.map((topic, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="font-medium">{topic}</span>
                    <Badge variant="outline" className="border-orange-300 text-orange-700">
                      In Progress
                    </Badge>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">
                  Continue studying to identify areas for improvement
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Study Sessions</CardTitle>
          <CardDescription>Your latest study activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {stats.recentSessions.length > 0 ? (
              stats.recentSessions.map((session, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium">{new Date(session.date).toLocaleDateString()}</p>
                    <p className="text-sm text-gray-600">{session.itemsStudied} items studied</p>
                  </div>
                  <div className="w-48">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-600">Accuracy</span>
                      <span className="text-sm font-semibold">{session.accuracy}%</span>
                    </div>
                    <Progress value={session.accuracy} className="h-2" />
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-8">
                No study sessions yet. Start practicing to see your activity!
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      {studySessions.length > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-900">Personalized Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-blue-900">
              {stats.averageAccuracy < 70 && (
                <li>• Your accuracy is {stats.averageAccuracy}% - try reviewing materials before quizzes</li>
              )}
              {stats.averageAccuracy >= 70 && stats.averageAccuracy < 85 && (
                <li>• Good progress! Your accuracy is {stats.averageAccuracy}% - keep practicing to reach 85%+</li>
              )}
              {stats.averageAccuracy >= 85 && (
                <li>• Excellent work! You're maintaining {stats.averageAccuracy}% accuracy</li>
              )}
              {stats.streakDays > 0 && (
                <li>• Great job maintaining your {stats.streakDays}-day streak! Keep it going!</li>
              )}
              {stats.streakDays === 0 && (
                <li>• Start a study streak today! Daily practice helps retention</li>
              )}
              <li>• Consider using Memory Boost mode for spaced repetition learning</li>
              {documents.length > 0 && (
                <li>• You have {documents.length} document{documents.length !== 1 ? 's' : ''} - create flashcards and quizzes to study them</li>
              )}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
