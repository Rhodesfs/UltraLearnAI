import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, RotateCcw, Lightbulb, CheckCircle, XCircle, Loader2, Plus } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document, Flashcard } from "@/types";

interface FlashcardViewerProps {
  selectedDocument: Document | null;
  isPremium: boolean;
}

export function FlashcardViewer({ selectedDocument, isPremium }: FlashcardViewerProps) {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCompletion, setShowCompletion] = useState(false);

  const aiMutation = useAIChatMutation();

  useEffect(() => {
    if (selectedDocument && flashcards.length === 0) {
      generateFlashcards();
    }
  }, [selectedDocument]);

  const generateFlashcards = async () => {
    if (!selectedDocument) return;

    setIsGenerating(true);
    try {
      const contentToUse = selectedDocument.processedContent || selectedDocument.name;

      const result = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are a study assistant that creates educational flashcards. Generate exactly 10 flashcards based on the document content. Return ONLY a JSON array with this exact structure: [{\"question\": \"...\", \"answer\": \"...\", \"hint\": \"...\", \"explanation\": \"...\", \"difficulty\": \"easy|medium|hard\"}]. Do not include any other text.",
          },
          {
            role: "user",
            content: `Generate 10 educational flashcards from this document content:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}\n\nReturn only the JSON array of flashcards.`,
          },
        ],
      });

      // Parse AI response and create flashcards
      let generatedCards: Flashcard[] = [];

      try {
        // Try to extract JSON from the response
        const content = result.content;
        let jsonStr = content;

        // Look for JSON array in the response
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          jsonStr = jsonMatch[0];
        }

        const parsedCards = JSON.parse(jsonStr);

        if (Array.isArray(parsedCards) && parsedCards.length > 0) {
          generatedCards = parsedCards.map((card: any) => ({
            id: crypto.randomUUID(),
            documentId: selectedDocument.id,
            question: card.question || "No question provided",
            answer: card.answer || "No answer provided",
            hint: card.hint || "Think about the key concepts",
            explanation: card.explanation || "Review the material for context",
            difficulty: (card.difficulty === "easy" || card.difficulty === "medium" || card.difficulty === "hard")
              ? card.difficulty
              : "medium",
            correctCount: 0,
            incorrectCount: 0,
          }));
        }
      } catch (parseError) {
        console.error("Failed to parse AI response, using fallback:", parseError);
      }

      // Fallback if parsing fails or no cards generated
      if (generatedCards.length === 0) {
        generatedCards = Array.from({ length: 10 }, (_, i) => ({
          id: crypto.randomUUID(),
          documentId: selectedDocument.id,
          question: `Question ${i + 1} based on ${selectedDocument.name}: What are the key concepts covered?`,
          answer: `This flashcard is based on the document content. The AI will generate specific questions once the document is processed.`,
          hint: `Review the main topics in ${selectedDocument.name}`,
          explanation: `This tests your understanding of ${selectedDocument.name}`,
          difficulty: ["easy", "medium", "hard"][i % 3] as "easy" | "medium" | "hard",
          correctCount: 0,
          incorrectCount: 0,
        }));
      }

      setFlashcards(generatedCards);
    } catch (error) {
      console.error("Failed to generate flashcards:", error);

      // Error fallback - create generic cards so users can still use the feature
      const fallbackCards: Flashcard[] = Array.from({ length: 10 }, (_, i) => ({
        id: crypto.randomUUID(),
        documentId: selectedDocument.id,
        question: `Study question ${i + 1} for ${selectedDocument.name}`,
        answer: `Answer based on ${selectedDocument.name} content`,
        hint: `Think about the main concepts in the document`,
        explanation: `Review ${selectedDocument.name} for details`,
        difficulty: ["easy", "medium", "hard"][i % 3] as "easy" | "medium" | "hard",
        correctCount: 0,
        incorrectCount: 0,
      }));
      setFlashcards(fallbackCards);
    } finally {
      setIsGenerating(false);
    }
  };

  const currentCard = flashcards[currentIndex];

  const handleNext = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
      setShowHint(false);
    } else {
      // Show completion screen when reaching the end
      setShowCompletion(true);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setIsFlipped(false);
      setShowHint(false);
    }
  };

  const handleCorrect = () => {
    if (currentCard) {
      setFlashcards((prev) => prev.map(card =>
        card.id === currentCard.id
          ? { ...card, correctCount: card.correctCount + 1 }
          : card
      ));
      handleNext();
    }
  };

  const handleIncorrect = () => {
    if (currentCard) {
      setFlashcards((prev) => prev.map(card =>
        card.id === currentCard.id
          ? { ...card, incorrectCount: card.incorrectCount + 1 }
          : card
      ));
      handleNext();
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowHint(false);
    setShowCompletion(false);
  };

  const handleGenerateNew = () => {
    setFlashcards([]);
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowHint(false);
    setShowCompletion(false);
    generateFlashcards();
  };

  if (!selectedDocument) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-8 sm:p-12 text-center">
          <p className="text-gray-500 dark:text-gray-400">Please upload and select a document to generate flashcards</p>
        </CardContent>
      </Card>
    );
  }

  if (isGenerating) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-8 sm:p-12 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 dark:text-gray-300" />
          <p className="text-gray-600 dark:text-gray-400">Generating AI-powered flashcards...</p>
        </CardContent>
      </Card>
    );
  }

  if (flashcards.length === 0) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-8 sm:p-12 text-center">
          <Button onClick={generateFlashcards}>Generate Flashcards</Button>
        </CardContent>
      </Card>
    );
  }

  // Calculate total correct and incorrect
  const totalCorrect = flashcards.reduce((sum, card) => sum + card.correctCount, 0);
  const totalIncorrect = flashcards.reduce((sum, card) => sum + card.incorrectCount, 0);

  // Show completion screen
  if (showCompletion) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="dark:text-white">Flashcards Complete! 🎉</CardTitle>
          <CardDescription className="dark:text-gray-400">
            You've reviewed all {flashcards.length} flashcards from {selectedDocument.name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg p-6 sm:p-8 text-center space-y-4">
            <div className="flex justify-center gap-4 sm:gap-8 text-base sm:text-lg flex-wrap">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-600 dark:text-green-400" />
                <span className="font-semibold dark:text-gray-200">{totalCorrect} Correct</span>
              </div>
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-red-600 dark:text-red-400" />
                <span className="font-semibold dark:text-gray-200">{totalIncorrect} Wrong</span>
              </div>
            </div>
            {totalCorrect + totalIncorrect > 0 && (
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Accuracy: {Math.round((totalCorrect / (totalCorrect + totalIncorrect)) * 100)}%
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3">
            <Button onClick={handleGenerateNew} className="w-full" size="lg">
              <Plus className="w-5 h-5 mr-2" />
              Add New Questions
            </Button>
            <Button onClick={handleRestart} variant="outline" className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700" size="lg">
              <RotateCcw className="w-5 h-5 mr-2" />
              Restart Flashcards
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="dark:text-white">Smart Flashcards</CardTitle>
        <CardDescription className="dark:text-gray-400">
          Card {currentIndex + 1} of {flashcards.length} • {selectedDocument.name}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex justify-between items-center">
          <Badge variant={currentCard.difficulty === "easy" ? "default" : currentCard.difficulty === "medium" ? "secondary" : "destructive"}>
            {currentCard.difficulty}
          </Badge>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            ✓ {currentCard.correctCount} | ✗ {currentCard.incorrectCount}
          </div>
        </div>

        <div
          className="min-h-[250px] sm:min-h-[300px] bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg p-6 sm:p-8 cursor-pointer flex items-center justify-center text-center transition-all hover:shadow-md dark:hover:shadow-gray-900"
          onClick={() => setIsFlipped(!isFlipped)}
        >
          <div className="space-y-4">
            <p className="text-lg sm:text-xl font-semibold dark:text-white">
              {isFlipped ? currentCard.answer : currentCard.question}
            </p>
            {isFlipped && currentCard.explanation && (
              <p className="text-sm text-gray-600 dark:text-gray-400 italic mt-4">{currentCard.explanation}</p>
            )}
            {!isFlipped && (
              <p className="text-sm text-gray-500 dark:text-gray-400">Click to flip</p>
            )}
          </div>
        </div>

        {!isFlipped && (
          <Button
            variant="outline"
            onClick={() => setShowHint(!showHint)}
            className="w-full dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700"
          >
            <Lightbulb className="w-4 h-4 mr-2" />
            {showHint ? "Hide Hint" : "Show Hint"}
          </Button>
        )}

        {showHint && !isFlipped && currentCard.hint && (
          <Alert className="dark:bg-gray-700 dark:border-gray-600">
            <Lightbulb className="h-4 w-4 dark:text-yellow-400" />
            <AlertDescription className="dark:text-gray-300">{currentCard.hint}</AlertDescription>
          </Alert>
        )}

        {isFlipped && (
          <div className="flex gap-3">
            <Button onClick={handleIncorrect} variant="destructive" className="flex-1">
              <XCircle className="w-4 h-4 mr-2" />
              Incorrect
            </Button>
            <Button onClick={handleCorrect} className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800">
              <CheckCircle className="w-4 h-4 mr-2" />
              Correct
            </Button>
          </div>
        )}

        <div className="flex flex-wrap justify-between items-center pt-4 gap-2">
          <Button onClick={handlePrevious} disabled={currentIndex === 0} variant="outline" className="dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700" size="sm">
            <ChevronLeft className="w-4 h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Previous</span>
            <span className="sm:hidden">Prev</span>
          </Button>
          <Button onClick={() => { setCurrentIndex(0); setIsFlipped(false); setShowHint(false); }} variant="ghost" className="dark:text-gray-300 dark:hover:bg-gray-700" size="sm">
            <RotateCcw className="w-4 h-4 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Restart</span>
          </Button>
          <Button onClick={handleNext} disabled={currentIndex === flashcards.length - 1} variant="outline" className="dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700" size="sm">
            <span className="hidden sm:inline">Next</span>
            <ChevronRight className="w-4 h-4 ml-1 sm:ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
