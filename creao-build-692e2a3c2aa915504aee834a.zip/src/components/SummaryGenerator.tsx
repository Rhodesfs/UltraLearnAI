import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, FileText, List, BookOpen, Download } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document } from "@/types";

interface SummaryGeneratorProps {
  selectedDocument: Document | null;
  isPremium: boolean;
}

export function SummaryGenerator({ selectedDocument, isPremium }: SummaryGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [bulletPoints, setBulletPoints] = useState<string>("");
  const [keyTerms, setKeyTerms] = useState<string>("");
  const [exampleQuestions, setExampleQuestions] = useState<string>("");

  const aiMutation = useAIChatMutation();

  const handleGenerateSummary = async () => {
    if (!selectedDocument) return;

    setIsGenerating(true);
    setBulletPoints("");
    setKeyTerms("");
    setExampleQuestions("");

    try {
      const contentToUse = selectedDocument.processedContent || selectedDocument.name;

      // Generate bullet point summary
      const bulletResult = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are a study assistant that creates concise bullet-point summaries.",
          },
          {
            role: "user",
            content: `Create a comprehensive bullet-point summary of key concepts from this document:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}`,
          },
        ],
      });
      setBulletPoints(bulletResult.content);

      // Generate key terms
      const termsResult = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are a study assistant that identifies and defines key terms.",
          },
          {
            role: "user",
            content: `Extract and define the most important terms and concepts from this document:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}`,
          },
        ],
      });
      setKeyTerms(termsResult.content);

      // Generate example questions
      const questionsResult = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are a study assistant that creates practice questions.",
          },
          {
            role: "user",
            content: `Generate 10 example questions that test understanding of this document:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}`,
          },
        ],
      });
      setExampleQuestions(questionsResult.content);
    } catch (error) {
      console.error("Failed to generate summary:", error);
      alert("Failed to generate summary. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  if (!selectedDocument) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <p className="text-gray-500">Please upload and select a document to generate summaries</p>
        </CardContent>
      </Card>
    );
  }

  const hasSummary = bulletPoints || keyTerms || exampleQuestions;

  if (isGenerating && !hasSummary) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-lg font-semibold text-gray-700 mb-2">Generating Smart Summary...</p>
          <p className="text-sm text-gray-500">AI is analyzing {selectedDocument?.name}</p>
          <p className="text-xs text-gray-400 mt-2">Creating bullet points, key terms, and practice questions</p>
          <p className="text-xs text-gray-400">This may take 60-90 seconds</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Smart Summary Generator</CardTitle>
          <CardDescription>
            Convert lengthy chapters into bullet-point notes, key terms, and example questions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!hasSummary ? (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-blue-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Generate Study Materials</h3>
              <p className="text-gray-600 mb-6">
                AI will analyze {selectedDocument.name} and create comprehensive study materials
              </p>
              <Button onClick={handleGenerateSummary} disabled={isGenerating} size="lg">
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Summary...
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Smart Summary
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Summary for {selectedDocument.name}</h3>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>

              <Tabs defaultValue="bullets">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="bullets">Bullet Points</TabsTrigger>
                  <TabsTrigger value="terms">Key Terms</TabsTrigger>
                  <TabsTrigger value="questions">Example Questions</TabsTrigger>
                </TabsList>

                <TabsContent value="bullets" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <List className="w-4 h-4" />
                        Bullet-Point Summary
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isGenerating ? (
                        <div className="flex items-center justify-center py-8">
                          <Loader2 className="w-6 h-6 animate-spin" />
                        </div>
                      ) : (
                        <div className="prose max-w-none">
                          <div className="whitespace-pre-wrap text-gray-700">
                            {bulletPoints || "Generating..."}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="terms" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <BookOpen className="w-4 h-4" />
                        Key Terms & Definitions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isGenerating ? (
                        <div className="flex items-center justify-center py-8">
                          <Loader2 className="w-6 h-6 animate-spin" />
                        </div>
                      ) : (
                        <div className="prose max-w-none">
                          <div className="whitespace-pre-wrap text-gray-700">
                            {keyTerms || "Generating..."}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="questions" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        Example Questions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isGenerating ? (
                        <div className="flex items-center justify-center py-8">
                          <Loader2 className="w-6 h-6 animate-spin" />
                        </div>
                      ) : (
                        <div className="prose max-w-none">
                          <div className="whitespace-pre-wrap text-gray-700">
                            {exampleQuestions || "Generating..."}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <Alert className="border-blue-200 bg-blue-50">
                <AlertDescription className="text-blue-900">
                  {isPremium
                    ? "As a Premium member, you can download these summaries as PDF files!"
                    : "Upgrade to Premium to download summaries as PDF files!"}
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
