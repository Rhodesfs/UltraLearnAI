import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Upload, FileText, Lock } from "lucide-react";
import { useFileUploadMutation } from "@/hooks/use-file-upload";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document } from "@/types";

interface DocumentUploadProps {
  onDocumentUploaded: (doc: Document) => void;
  isPremium: boolean;
  documentCount: number;
}

export function DocumentUpload({ onDocumentUploaded, isPremium, documentCount }: DocumentUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const uploadMutation = useFileUploadMutation();
  const aiMutation = useAIChatMutation();

  const FREE_LIMIT = 3;
  const canUpload = isPremium || documentCount < FREE_LIMIT;

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setError(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    if (!canUpload) {
      setError(`Free users can upload up to ${FREE_LIMIT} documents. Upgrade to Premium for unlimited uploads!`);
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setError(null);

    try {
      // Step 1: Upload file (30% progress)
      setProgress(30);
      const uploadResult = await uploadMutation.mutateAsync({ file: selectedFile });

      // Step 2: Extract content using AI (60% progress)
      setProgress(60);
      const extractionResult = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are a document content extractor. Extract and return the main text content from documents in a clean, structured format.",
          },
          {
            role: "user",
            content: `Extract the content from this document: ${selectedFile.name}. Since this is a file upload, please acknowledge that the document has been uploaded and is ready for study material generation.`,
          },
        ],
      });

      // Step 3: Create document record (100% progress)
      setProgress(100);
      const newDocument: Document = {
        id: crypto.randomUUID(),
        name: selectedFile.name,
        type: selectedFile.type || "application/octet-stream",
        uploadedAt: new Date(),
        fileUrl: uploadResult.uploadedFileUrl,
        fileKey: uploadResult.fileKey,
        processedContent: extractionResult.content,
      };

      onDocumentUploaded(newDocument);
      setSelectedFile(null);
      setProgress(0);

      // Reset file input
      const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
      if (fileInput) fileInput.value = "";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed. Please try again.");
      setProgress(0);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      {!canUpload && (
        <Alert className="border-orange-500 bg-orange-50">
          <Lock className="h-4 w-4" />
          <AlertDescription>
            You've reached the free tier limit of {FREE_LIMIT} documents. Upgrade to Premium for unlimited uploads!
          </AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <Input
            type="file"
            onChange={handleFileSelect}
            accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg"
            disabled={isProcessing || !canUpload}
            className="flex-1"
          />
          <Button
            onClick={handleUpload}
            disabled={!selectedFile || isProcessing || !canUpload}
            className="min-w-[120px]"
          >
            {isProcessing ? (
              <>Processing...</>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </>
            )}
          </Button>
        </div>

        {selectedFile && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <FileText className="w-4 h-4" />
            <span>{selectedFile.name} ({(selectedFile.size / 1024).toFixed(2)} KB)</span>
          </div>
        )}

        {isProcessing && (
          <div className="space-y-2">
            <Progress value={progress} className="w-full" />
            <p className="text-sm text-gray-600 text-center">
              {progress < 40 ? "Uploading file..." : progress < 80 ? "Processing content..." : "Finalizing..."}
            </p>
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </div>

      <div className="text-sm text-gray-500 mt-4">
        <p className="font-semibold mb-2">Supported formats:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>PDF documents (.pdf)</li>
          <li>Word documents (.doc, .docx)</li>
          <li>Text files (.txt)</li>
          <li>Images with text (.png, .jpg, .jpeg)</li>
        </ul>
      </div>
    </div>
  );
}
