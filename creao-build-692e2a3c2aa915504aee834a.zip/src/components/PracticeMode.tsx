import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document, QuizQuestion } from "@/types";

interface PracticeModeProps {
  selectedDocument: Document | null;
  isPremium: boolean;
}

export function PracticeMode({ selectedDocument, isPremium }: PracticeModeProps) {
  const [quizType, setQuizType] = useState<string>("multiple-choice");
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [wrongAnswers, setWrongAnswers] = useState(0);
  const [quizStarted, setQuizStarted] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const aiMutation = useAIChatMutation();

  const startQuiz = async () => {
    if (!selectedDocument) return;

    setIsGenerating(true);
    setQuizStarted(true);

    try {
      const contentToUse = selectedDocument.processedContent || selectedDocument.name;

      const result = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: `You are an expert quiz creator. Generate exactly 10 ${quizType} questions based on the document content. Return ONLY a JSON array with this exact structure: [{\"question\": \"...\", \"correctAnswer\": \"...\", ${quizType === "multiple-choice" ? "\"options\": [\"...\", \"...\", \"...\", \"...\"], " : ""}\"explanation\": \"...\"}]. For true-false questions, correctAnswer must be exactly "True" or "False". Do not include any other text.`,
          },
          {
            role: "user",
            content: `Generate 10 ${quizType} questions from this document:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}\n\nReturn only the JSON array of questions.`,
          },
        ],
      });

      let generatedQuestions: QuizQuestion[] = [];

      try {
        const content = result.content;
        let jsonStr = content;

        // Look for JSON array in the response
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          jsonStr = jsonMatch[0];
        }

        const parsedQuestions = JSON.parse(jsonStr);

        if (Array.isArray(parsedQuestions) && parsedQuestions.length > 0) {
          generatedQuestions = parsedQuestions.map((q: any) => ({
            id: crypto.randomUUID(),
            documentId: selectedDocument.id,
            type: quizType as QuizQuestion["type"],
            question: q.question || "No question provided",
            correctAnswer: q.correctAnswer || "",
            options: q.options || (quizType === "true-false" ? ["True", "False"] : undefined),
            explanation: q.explanation || "Review the material for context",
          }));
        }
      } catch (parseError) {
        console.error("Failed to parse AI response:", parseError);
      }

      // Fallback if parsing fails
      if (generatedQuestions.length === 0) {
        generatedQuestions = Array.from({ length: 10 }, (_, i) => ({
          id: crypto.randomUUID(),
          documentId: selectedDocument.id,
          type: quizType as QuizQuestion["type"],
          question: `Question ${i + 1} based on ${selectedDocument.name}`,
          correctAnswer: quizType === "true-false" ? "True" : "Answer will be generated",
          options: quizType === "multiple-choice" ? ["Option A", "Option B", "Option C", "Option D"] :
                   quizType === "true-false" ? ["True", "False"] : undefined,
          explanation: "This tests your understanding of the material.",
        }));
      }

      setQuestions(generatedQuestions);
      setCurrentQuestion(0);
      setScore(0);
      setWrongAnswers(0);
      setShowResult(false);
    } catch (error) {
      console.error("Failed to generate quiz:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmitAnswer = () => {
    if (!selectedAnswer) return;

    const isCorrect = selectedAnswer === questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore((prev) => prev + 1);
    } else {
      setWrongAnswers((prev) => prev + 1);
    }
    setShowResult(true);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer("");
      setShowResult(false);
    }
  };

  const handleFinish = () => {
    const totalAnswered = score + wrongAnswers;
    const percentage = totalAnswered > 0 ? Math.round((score / totalAnswered) * 100) : 0;
    alert(`Quiz completed!\n\nCorrect: ${score}\nIncorrect: ${wrongAnswers}\nTotal: ${totalAnswered}\n\nAccuracy: ${percentage}%`);
    setQuizStarted(false);
  };

  if (!selectedDocument) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-12 text-center">
          <p className="text-gray-500 dark:text-gray-400">Please upload and select a document to start practicing</p>
        </CardContent>
      </Card>
    );
  }

  if (!quizStarted) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="dark:text-white">Practice Mode</CardTitle>
          <CardDescription className="dark:text-gray-400">Choose your practice format and test your knowledge</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Label className="dark:text-gray-300">Select Practice Format</Label>
            <Select value={quizType} onValueChange={setQuizType}>
              <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="dark:bg-gray-700 dark:border-gray-600">
                <SelectItem value="multiple-choice" className="dark:text-white dark:focus:bg-gray-600">Multiple Choice</SelectItem>
                <SelectItem value="true-false" className="dark:text-white dark:focus:bg-gray-600">True/False</SelectItem>
                <SelectItem value="fill-blank" className="dark:text-white dark:focus:bg-gray-600">Fill in the Blank</SelectItem>
                <SelectItem value="short-answer" className="dark:text-white dark:focus:bg-gray-600">Short Answer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={startQuiz} className="w-full" size="lg" disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Quiz...
              </>
            ) : (
              "Start Practice Quiz"
            )}
          </Button>

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">10</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Questions</p>
            </div>
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">~15 min</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Duration</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isGenerating) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-12 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 dark:text-gray-400" />
          <p className="text-gray-600 dark:text-gray-300">Generating AI-powered quiz questions...</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">This may take a moment</p>
        </CardContent>
      </Card>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="dark:text-white">Practice Quiz</CardTitle>
        <CardDescription className="dark:text-gray-400">
          Question {currentQuestion + 1} of {questions.length}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Progress value={progress} className="w-full" />

        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/30 dark:to-indigo-900/30 rounded-lg p-6">
          <p className="text-lg font-semibold mb-4 dark:text-white">{currentQ.question}</p>

          {currentQ.type === "multiple-choice" && currentQ.options && (
            <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} disabled={showResult}>
              <div className="space-y-3">
                {currentQ.options.map((option, idx) => (
                  <div key={idx} className="flex items-center space-x-2 p-3 bg-white dark:bg-gray-700 rounded-md">
                    <RadioGroupItem value={option} id={`option-${idx}`} />
                    <Label htmlFor={`option-${idx}`} className="flex-1 cursor-pointer dark:text-gray-200">
                      {option}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          )}

          {currentQ.type === "true-false" && (
            <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} disabled={showResult}>
              <div className="space-y-3">
                <div className="flex items-center space-x-2 p-3 bg-white dark:bg-gray-700 rounded-md">
                  <RadioGroupItem value="True" id="true" />
                  <Label htmlFor="true" className="flex-1 cursor-pointer dark:text-gray-200">True</Label>
                </div>
                <div className="flex items-center space-x-2 p-3 bg-white dark:bg-gray-700 rounded-md">
                  <RadioGroupItem value="False" id="false" />
                  <Label htmlFor="false" className="flex-1 cursor-pointer dark:text-gray-200">False</Label>
                </div>
              </div>
            </RadioGroup>
          )}

          {(currentQ.type === "fill-blank" || currentQ.type === "short-answer") && (
            <Input
              value={selectedAnswer}
              onChange={(e) => setSelectedAnswer(e.target.value)}
              placeholder="Type your answer..."
              disabled={showResult}
              className="bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder:text-gray-400"
            />
          )}
        </div>

        {showResult && (
          <Alert variant={selectedAnswer === currentQ.correctAnswer ? "default" : "destructive"}>
            {selectedAnswer === currentQ.correctAnswer ? (
              <CheckCircle className="h-4 w-4" />
            ) : (
              <XCircle className="h-4 w-4" />
            )}
            <AlertDescription>
              {selectedAnswer === currentQ.correctAnswer ? (
                <span className="font-semibold">Correct!</span>
              ) : (
                <span>
                  <span className="font-semibold">Incorrect.</span> The correct answer is: {currentQ.correctAnswer}
                </span>
              )}
              {currentQ.explanation && <p className="mt-2 text-sm">{currentQ.explanation}</p>}
            </AlertDescription>
          </Alert>
        )}

        <div className="flex gap-3">
          {!showResult ? (
            <Button onClick={handleSubmitAnswer} disabled={!selectedAnswer} className="flex-1">
              Submit Answer
            </Button>
          ) : currentQuestion < questions.length - 1 ? (
            <Button onClick={handleNext} className="flex-1">
              Next Question
            </Button>
          ) : (
            <Button onClick={handleFinish} className="flex-1 bg-green-600 hover:bg-green-700">
              Finish Quiz
            </Button>
          )}
        </div>

        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 pt-4 border-t dark:border-gray-700">
          <div className="flex gap-4">
            <span className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
              Correct: {score}
            </span>
            <span className="flex items-center gap-1">
              <XCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
              Wrong: {wrongAnswers}
            </span>
          </div>
          <span>Accuracy: {score + wrongAnswers > 0 ? Math.round((score / (score + wrongAnswers)) * 100) : 0}%</span>
        </div>
      </CardContent>
    </Card>
  );
}
