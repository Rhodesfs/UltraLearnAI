import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar, Brain, CheckCircle, XCircle, Zap, Loader2, AlertCircle } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document, Flashcard } from "@/types";

interface MemoryBoostProps {
  isPremium: boolean;
  documents: Document[];
}

export function MemoryBoost({ isPremium, documents }: MemoryBoostProps) {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [todayCompleted, setTodayCompleted] = useState(0);
  const [streakDays, setStreakDays] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [intervals, setIntervals] = useState<Map<string, number>>(new Map());

  const aiMutation = useAIChatMutation();

  const dailyGoal = 20;
  const progress = (todayCompleted / dailyGoal) * 100;

  useEffect(() => {
    if (documents.length > 0 && flashcards.length === 0) {
      generateFlashcardsFromDocuments();
    }
  }, [documents]);

  const generateFlashcardsFromDocuments = async () => {
    if (documents.length === 0) return;

    setIsGenerating(true);
    try {
      const allFlashcards: Flashcard[] = [];

      // Generate flashcards from all documents
      for (const doc of documents.slice(0, 3)) { // Limit to first 3 documents
        const contentToUse = doc.processedContent || doc.name;

        const result = await aiMutation.mutateAsync({
          messages: [
            {
              role: "system",
              content: "You are a study assistant that creates educational flashcards. Generate exactly 5 flashcards based on the document content. Return ONLY a JSON array with this exact structure: [{\"question\": \"...\", \"answer\": \"...\", \"hint\": \"...\", \"explanation\": \"...\"}]. Do not include any other text.",
            },
            {
              role: "user",
              content: `Generate 5 educational flashcards from this document:\n\nDocument: ${doc.name}\nContent: ${contentToUse}\n\nReturn only the JSON array of flashcards.`,
            },
          ],
        });

        try {
          const content = result.content;
          let jsonStr = content;
          const jsonMatch = content.match(/\[[\s\S]*\]/);
          if (jsonMatch) {
            jsonStr = jsonMatch[0];
          }

          const parsedCards = JSON.parse(jsonStr);

          if (Array.isArray(parsedCards) && parsedCards.length > 0) {
            const cards = parsedCards.map((card: any) => ({
              id: crypto.randomUUID(),
              documentId: doc.id,
              question: card.question || "No question provided",
              answer: card.answer || "No answer provided",
              hint: card.hint || "Think about the key concepts",
              explanation: card.explanation || "Review the material for context",
              difficulty: "medium" as const,
              correctCount: 0,
              incorrectCount: 0,
            }));
            allFlashcards.push(...cards);
          }
        } catch (parseError) {
          console.error("Failed to parse flashcards:", parseError);
        }
      }

      if (allFlashcards.length > 0) {
        setFlashcards(allFlashcards);
        // Initialize intervals for all flashcards
        const newIntervals = new Map<string, number>();
        allFlashcards.forEach(card => newIntervals.set(card.id, 1));
        setIntervals(newIntervals);
      }
    } catch (error) {
      console.error("Failed to generate flashcards:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEasyResponse = () => {
    const currentCard = flashcards[currentIndex];
    if (currentCard) {
      // Increase interval significantly (easy = 4x current interval)
      const currentInterval = intervals.get(currentCard.id) || 1;
      intervals.set(currentCard.id, currentInterval * 4);
      setIntervals(new Map(intervals));

      // Update correct count
      setFlashcards(flashcards.map(card =>
        card.id === currentCard.id
          ? { ...card, correctCount: card.correctCount + 1 }
          : card
      ));
    }
    handleNext();
  };

  const handleMediumResponse = () => {
    const currentCard = flashcards[currentIndex];
    if (currentCard) {
      // Moderate interval increase (medium = 2x current interval)
      const currentInterval = intervals.get(currentCard.id) || 1;
      intervals.set(currentCard.id, currentInterval * 2);
      setIntervals(new Map(intervals));

      // Update correct count
      setFlashcards(flashcards.map(card =>
        card.id === currentCard.id
          ? { ...card, correctCount: card.correctCount + 1 }
          : card
      ));
    }
    handleNext();
  };

  const handleHardResponse = () => {
    const currentCard = flashcards[currentIndex];
    if (currentCard) {
      // Reset to 1 day interval for hard cards
      intervals.set(currentCard.id, 1);
      setIntervals(new Map(intervals));

      // Update incorrect count
      setFlashcards(flashcards.map(card =>
        card.id === currentCard.id
          ? { ...card, incorrectCount: card.incorrectCount + 1 }
          : card
      ));
    }
    handleNext();
  };

  const handleNext = () => {
    setTodayCompleted(todayCompleted + 1);
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setIsFlipped(false);
    } else {
      // Session complete - restart from beginning
      setCurrentIndex(0);
      setIsFlipped(false);
      setStreakDays(streakDays + 1);
    }
  };

  if (documents.length === 0) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-12 text-center">
          <AlertCircle className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">Please upload documents first to use Memory Boost</p>
        </CardContent>
      </Card>
    );
  }

  if (isGenerating) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-12 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 dark:text-gray-400" />
          <p className="text-gray-600 dark:text-gray-300">Generating flashcards for spaced repetition...</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">This may take a moment</p>
        </CardContent>
      </Card>
    );
  }

  if (flashcards.length === 0) {
    return (
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 dark:text-white">
            <Zap className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            Memory Boost Mode
          </CardTitle>
          <CardDescription className="dark:text-gray-400">Daily spaced-repetition trainer with scientifically optimized review cycles</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800">
            <AlertCircle className="h-4 w-4 dark:text-blue-400" />
            <AlertDescription className="dark:text-blue-300">
              Memory Boost will generate flashcards from your uploaded documents. Upload some documents to get started!
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  const currentCard = flashcards[currentIndex];
  const currentInterval = intervals.get(currentCard.id) || 1;

  return (
    <div className="space-y-6">
      {/* Daily Progress */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 dark:text-white">
            <Zap className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            Memory Boost Mode
          </CardTitle>
          <CardDescription className="dark:text-gray-400">Daily spaced-repetition trainer with scientifically optimized review cycles</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{todayCompleted}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Reviewed Today</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-orange-600 dark:text-orange-400">{flashcards.length}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Cards</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-3xl font-bold text-green-600 dark:text-green-400">{streakDays}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Day Streak</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium dark:text-gray-300">Daily Goal Progress</span>
              <span className="text-sm text-gray-600 dark:text-gray-400">{todayCompleted}/{dailyGoal}</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Spaced Repetition Training */}
      {flashcards.length > 0 ? (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="dark:text-white">Review Session</CardTitle>
              <Badge variant="outline" className="dark:border-gray-600 dark:text-gray-300">
                {currentIndex + 1} of {flashcards.length}
              </Badge>
            </div>
            <CardDescription className="dark:text-gray-400">
              This card will be reviewed again in {currentInterval} day{currentInterval !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div
              className="min-h-[300px] bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/30 dark:to-indigo-900/30 rounded-lg p-8 cursor-pointer flex items-center justify-center text-center transition-all hover:shadow-md"
              onClick={() => setIsFlipped(!isFlipped)}
            >
              <div className="space-y-4">
                <p className="text-xl font-semibold dark:text-white">
                  {isFlipped ? currentCard.answer : currentCard.question}
                </p>
                {isFlipped && currentCard.explanation && (
                  <p className="text-sm text-gray-600 dark:text-gray-300 italic mt-4">{currentCard.explanation}</p>
                )}
                {!isFlipped && (
                  <p className="text-sm text-gray-500 dark:text-gray-400">Click to reveal answer</p>
                )}
              </div>
            </div>

            {!isFlipped ? (
              <Button variant="outline" onClick={() => setIsFlipped(true)} className="w-full">
                Show Answer
              </Button>
            ) : (
              <div className="space-y-3">
                <p className="text-center font-medium text-gray-700 dark:text-gray-300">How well did you remember?</p>
                <div className="grid grid-cols-3 gap-3">
                  <Button
                    onClick={handleHardResponse}
                    variant="outline"
                    className="border-red-300 hover:bg-red-50 dark:border-red-800 dark:hover:bg-red-900/30"
                  >
                    <XCircle className="w-4 h-4 mr-2 text-red-600 dark:text-red-400" />
                    Hard
                  </Button>
                  <Button
                    onClick={handleMediumResponse}
                    variant="outline"
                    className="border-yellow-300 hover:bg-yellow-50 dark:border-yellow-800 dark:hover:bg-yellow-900/30"
                  >
                    <Brain className="w-4 h-4 mr-2 text-yellow-600 dark:text-yellow-400" />
                    Medium
                  </Button>
                  <Button
                    onClick={handleEasyResponse}
                    variant="outline"
                    className="border-green-300 hover:bg-green-50 dark:border-green-800 dark:hover:bg-green-900/30"
                  >
                    <CheckCircle className="w-4 h-4 mr-2 text-green-600 dark:text-green-400" />
                    Easy
                  </Button>
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400 text-center mt-2">
                  <p>Hard: Review again soon • Medium: Standard interval • Easy: Longer interval</p>
                </div>
              </div>
            )}

            <div className="pt-4 border-t dark:border-gray-700">
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Reviews: ✓ {currentCard.correctCount} | ✗ {currentCard.incorrectCount}
                </span>
                <span>Next: {currentInterval} day{currentInterval !== 1 ? "s" : ""}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 dark:text-green-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2 dark:text-white">All Caught Up!</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              You've reviewed all cards due today. Great work!
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Come back tomorrow to continue building your memory strength
            </p>
          </CardContent>
        </Card>
      )}

      {/* Learning Schedule */}
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="dark:text-white">Upcoming Reviews</CardTitle>
          <CardDescription className="dark:text-gray-400">Your scientifically optimized learning schedule</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { date: "Today", count: flashcards.filter(c => (intervals.get(c.id) || 1) === 1).length, color: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400" },
              { date: "Tomorrow", count: flashcards.filter(c => (intervals.get(c.id) || 1) === 2).length, color: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400" },
              { date: "In 2-4 days", count: flashcards.filter(c => {
                const interval = intervals.get(c.id) || 1;
                return interval >= 2 && interval <= 4;
              }).length, color: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400" },
              { date: "In 4-8 days", count: flashcards.filter(c => {
                const interval = intervals.get(c.id) || 1;
                return interval > 4 && interval <= 8;
              }).length, color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" },
              { date: "In 8+ days", count: flashcards.filter(c => (intervals.get(c.id) || 1) > 8).length, color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <span className="font-medium dark:text-gray-200">{item.date}</span>
                <Badge className={item.color}>
                  {item.count} cards
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
