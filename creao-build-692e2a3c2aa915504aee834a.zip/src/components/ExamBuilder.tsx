import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, FileText, Download, Lock } from "lucide-react";
import { useAIChatMutation } from "@/hooks/use-ai-chat";
import type { Document } from "@/types";

interface ExamBuilderProps {
  selectedDocument: Document | null;
  isPremium: boolean;
}

export function ExamBuilder({ selectedDocument, isPremium }: ExamBuilderProps) {
  const [questionCount, setQuestionCount] = useState([50]);
  const [includeMultipleChoice, setIncludeMultipleChoice] = useState(true);
  const [includeTrueFalse, setIncludeTrueFalse] = useState(true);
  const [includeFillBlank, setIncludeFillBlank] = useState(false);
  const [includeShortAnswer, setIncludeShortAnswer] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedExam, setGeneratedExam] = useState<string | null>(null);

  const aiMutation = useAIChatMutation();

  const handleGenerateExam = async () => {
    if (!selectedDocument || !isPremium) return;

    setIsGenerating(true);
    setGeneratedExam(null);

    try {
      const contentToUse = selectedDocument.processedContent || selectedDocument.name;

      const questionTypes = [];
      if (includeMultipleChoice) questionTypes.push("multiple-choice");
      if (includeTrueFalse) questionTypes.push("true/false");
      if (includeFillBlank) questionTypes.push("fill-in-the-blank");
      if (includeShortAnswer) questionTypes.push("short-answer");

      const result = await aiMutation.mutateAsync({
        messages: [
          {
            role: "system",
            content: "You are an expert exam creator. Generate comprehensive practice exams with clear questions, correct answers, and explanations.",
          },
          {
            role: "user",
            content: `Create a practice exam with ${questionCount[0]} questions from this document:\n\nDocument: ${selectedDocument.name}\nContent: ${contentToUse}\n\nInclude these question types: ${questionTypes.join(", ")}. Format as a clear, structured exam with question numbers, the questions, answer choices (for multiple choice), and an answer key at the end.`,
          },
        ],
      });

      setGeneratedExam(result.content);
    } catch (error) {
      console.error("Failed to generate exam:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  if (!selectedDocument) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <p className="text-gray-500">Please upload and select a document to build an exam</p>
        </CardContent>
      </Card>
    );
  }

  if (!isPremium) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Auto Exam Builder</CardTitle>
          <CardDescription>Generate comprehensive practice exams from your documents</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="border-orange-500 bg-orange-50">
            <Lock className="h-4 w-4" />
            <AlertDescription>
              Auto Exam Builder is a Premium feature. Upgrade to generate unlimited practice exams with 50-100 questions!
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  if (isGenerating) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-lg font-semibold text-gray-700 mb-2">Generating Your Practice Exam...</p>
          <p className="text-sm text-gray-500">AI is creating {questionCount[0]} questions from your document</p>
          <p className="text-xs text-gray-400 mt-2">This may take 30-60 seconds</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Auto Exam Builder</CardTitle>
          <CardDescription>
            Generate comprehensive practice exams from {selectedDocument.name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-3">
              <Label>Number of Questions: {questionCount[0]}</Label>
              <Slider
                value={questionCount}
                onValueChange={setQuestionCount}
                min={20}
                max={100}
                step={10}
                className="w-full"
              />
              <p className="text-sm text-gray-500">
                Generate between 20 and 100 questions
              </p>
            </div>

            <div className="space-y-3">
              <Label>Question Types</Label>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="multiple-choice"
                    checked={includeMultipleChoice}
                    onCheckedChange={(checked) => setIncludeMultipleChoice(checked as boolean)}
                  />
                  <Label htmlFor="multiple-choice" className="font-normal cursor-pointer">
                    Multiple Choice
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="true-false"
                    checked={includeTrueFalse}
                    onCheckedChange={(checked) => setIncludeTrueFalse(checked as boolean)}
                  />
                  <Label htmlFor="true-false" className="font-normal cursor-pointer">
                    True/False
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="fill-blank"
                    checked={includeFillBlank}
                    onCheckedChange={(checked) => setIncludeFillBlank(checked as boolean)}
                  />
                  <Label htmlFor="fill-blank" className="font-normal cursor-pointer">
                    Fill in the Blank
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="short-answer"
                    checked={includeShortAnswer}
                    onCheckedChange={(checked) => setIncludeShortAnswer(checked as boolean)}
                  />
                  <Label htmlFor="short-answer" className="font-normal cursor-pointer">
                    Short Answer
                  </Label>
                </div>
              </div>
            </div>
          </div>

          <Button
            onClick={handleGenerateExam}
            disabled={isGenerating}
            className="w-full"
            size="lg"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Exam...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Generate Practice Exam
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {generatedExam && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Generated Practice Exam</CardTitle>
                <CardDescription>{questionCount[0]} questions ready for review</CardDescription>
              </div>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 rounded-lg p-6 max-h-[600px] overflow-y-auto">
              <div className="whitespace-pre-wrap font-mono text-sm">
                {generatedExam}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
