import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { createChatCompletion } from '@/sdk/api-clients/OpenAIGPTChat';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AIChatInput {
  messages: ChatMessage[];
  model?: string;
}

export interface AIChatResponse {
  content: string;
  finishReason: 'stop' | 'length' | 'function_call' | 'content_filter' | 'null';
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  id: string;
  created: number;
}

export function useAIChatMutation(): UseMutationResult<
  AIChatResponse,
  Error,
  AIChatInput
> {
  return useMutation({
    mutationFn: async (input: AIChatInput): Promise<AIChatResponse> => {
      if (!input.messages || input.messages.length === 0) {
        throw new Error('At least one message is required');
      }

      // Validate message structure
      for (const message of input.messages) {
        if (!message.role || !message.content) {
          throw new Error('Each message must have a role and content');
        }
        if (!['system', 'user', 'assistant'].includes(message.role)) {
          throw new Error('Message role must be "system", "user", or "assistant"');
        }
      }

      const response = await createChatCompletion({
        body: {
          model: input.model || 'MaaS_4.1',
          messages: input.messages,
        },
        headers: {
          'X-CREAO-API-NAME': 'OpenAIGPTChat',
          'X-CREAO-API-PATH': '/v1/ai/zWwyutGgvEGWwzSa/chat/completions',
          'X-CREAO-API-ID': '688a0b64dc79a2533460892c',
        },
      });

      if (response.error) {
        throw new Error('AI chat completion failed. Please check your API credentials and try again.');
      }

      if (!response.data) {
        throw new Error('No response data returned from AI service');
      }

      const firstChoice = response.data.choices?.[0];
      if (!firstChoice) {
        throw new Error('No completion choices returned from AI service');
      }

      const messageContent = firstChoice.message?.content;
      if (!messageContent) {
        throw new Error('No message content in AI response');
      }

      return {
        content: messageContent,
        finishReason: firstChoice.finish_reason,
        usage: {
          promptTokens: response.data.usage.prompt_tokens,
          completionTokens: response.data.usage.completion_tokens,
          totalTokens: response.data.usage.total_tokens,
        },
        id: response.data.id,
        created: response.data.created,
      };
    },
  });
}
