import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { postMainOfficialApiPresignS3Upload } from '@/sdk/api-clients/CreaoFileUpload';

export interface FileUploadInput {
  file: File;
}

export interface FileUploadResponse {
  uploadedFileUrl: string;
  fileKey: string;
  expiresIn: number;
}

export function useFileUploadMutation(): UseMutationResult<
  FileUploadResponse,
  Error,
  FileUploadInput
> {
  return useMutation({
    mutationFn: async (input: FileUploadInput): Promise<FileUploadResponse> => {
      if (!input.file || !(input.file instanceof File)) {
        throw new Error('Valid file object is required');
      }

      const fileName = input.file.name;
      const contentType = input.file.type || 'application/octet-stream';

      // Step 1: Get presigned URL from API
      const presignResponse = await postMainOfficialApiPresignS3Upload({
        body: {
          fileName,
          contentType,
        },
        headers: {
          'X-CREAO-API-NAME': 'CreaoFileUpload',
          'X-CREAO-API-PATH': '/main/official-api/presign-s3-upload',
          'X-CREAO-API-ID': '68b68b97ac476c8df7efbeaf',
        },
      });

      if (presignResponse.error) {
        const errorMessage =
          typeof presignResponse.error === 'object' && presignResponse.error !== null && 'message' in presignResponse.error
            ? String(presignResponse.error.message)
            : 'Failed to generate presigned URL';
        throw new Error(errorMessage);
      }

      if (!presignResponse.data?.presignedUrl) {
        throw new Error('No presigned URL returned from server');
      }

      const { presignedUrl, realFileUrl, fileKey, expiresIn } = presignResponse.data;

      // Step 2: Upload file directly to S3 using presigned URL
      const uploadResponse = await fetch(presignedUrl, {
        method: 'PUT',
        headers: {
          'Content-Type': contentType,
        },
        body: input.file,
      });

      if (!uploadResponse.ok) {
        throw new Error(`File upload to S3 failed with status ${uploadResponse.status}`);
      }

      if (!realFileUrl) {
        throw new Error('No file URL returned after successful upload');
      }

      return {
        uploadedFileUrl: realFileUrl,
        fileKey: fileKey || '',
        expiresIn: expiresIn || 0,
      };
    },
  });
}
